#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ModelBridge::modelbridge_sdk" for configuration "Release"
set_property(TARGET ModelBridge::modelbridge_sdk APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ModelBridge::modelbridge_sdk PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libmodelbridge_sdk.a"
  )

list(APPEND _cmake_import_check_targets ModelBridge::modelbridge_sdk )
list(APPEND _cmake_import_check_files_for_ModelBridge::modelbridge_sdk "${_IMPORT_PREFIX}/lib/libmodelbridge_sdk.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
